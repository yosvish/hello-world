enum SnapshotIntervalEnum {
    Unknown = 0,
    Interval60 = 60,
    Interval45 = 45,
    Interval30 = 30,
    Interval20 = 20,
    Interval10 = 10,
    Interval5 = 5,
    Interval4 = 4,
    Interval3 = 3,
    Interval2 = 2,
    Interval1 = 1
}