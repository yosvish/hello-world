interface RecordedPlatformEntity {
    Id: string;
    Type: string;
	Name: string;
	PlatformId: number;
}