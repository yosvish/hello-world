interface OfflineRunEntity {
    Id: string;
    Type: string;
    RunId: string;
    Description: string;
    Owner: string;
    Repository: RunRepositoryEnum;
    DataSource: RunDataSourceTypeEnum;
	RecordedPlatform: RecordedPlatformEntity[];
    EngineVersion: VersionRecord;
    RulesVersion: VersionRecord;
    StartTime: Date;
    FinishTime: Date;
	RunDuration: number; //minutes
	SnapshotInterval;  //minutes
    PlaySpeed: PlaySpeedEnum;
}