enum RunRepositoryEnum {
    Uknown = 0,
    Operational = 1,
    Training = 2,
    Simulation = 3,
}