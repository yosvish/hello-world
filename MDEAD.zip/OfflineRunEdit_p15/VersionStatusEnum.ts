enum VersionStatusEnum {
    Unknown = 0,
    Operationa = 1,
    Experimental = 2,
	Previous = 3
}