enum PlaySpeedEnum {
    Unknown = 0,
    Normal = 1,
    Fast = 2,
}