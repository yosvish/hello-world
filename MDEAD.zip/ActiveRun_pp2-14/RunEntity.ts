interface RunEntity {
    Id: string;
    Type: string;
    RunId: string;
    Description: string;
    Owner: string;
    RunType: RunTypeEnum;
    DataSourceType: RunDataSourceTypeEnum;
    Repository: RunRepositoryEnum;
    EngineVersion: VersionRecord;
    RulesVersion: VersionRecord;
    OnlineSensors: OnlineSensorRecord[];
    StartTime: Date;
    PlannedFinishTime: Date;
    RunHealth: RunHealthEnum;
    RunComponentsHealth: RunDpComponent[];
    PlayTime: number;
	RunningState: RunningStateEnum;
}