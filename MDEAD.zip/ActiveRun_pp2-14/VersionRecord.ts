interface VersionRecord {
	VersionName: string;
	VersionStatus: VersionStatusEnum;
}