enum SensorStateEnum {
    Unknown = 0,
    Standby = 1,
    Active = 2,
    Disconnected = 3,
}