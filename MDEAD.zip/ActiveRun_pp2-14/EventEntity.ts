interface EventEntity {
    Id: string;
    Type: string;
    RunId: number;
    EventId: number;
    Confidence: ConfidenceEnum;
    Severity: SeverityEnum;
    Activity: EventActivityEnum;
    Faults: FaultRecord[];
    CreatedTime: Date;
    UpdatedTime: Date;
    SopSelectee: string; //uuid
    Fleets: number[];
    Navies: number[];
}