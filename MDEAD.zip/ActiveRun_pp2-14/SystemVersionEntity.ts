interface SystemVersionEntity {
    Id: string;
    Type: string;
	EngineVersions: VersionRecord[];
	RuleVersions: VersionRecord[];
}