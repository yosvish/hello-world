interface PlatformEntity {
	RunId: number;
	PlatformId: number;
	Name: string;
	FleetId: number;
	NavyId: number;
	Anomalies: AnomalyRecord[];
	Faults: FaultRecord[];
	Position: GeoPosition;
	Timetag: Date;
}