interface RunContentEntity {
    Id: string;
    Type: string;
    RunId: number;
    Events: EventEntity[];
    Platforms: PlatformEntity[];
}