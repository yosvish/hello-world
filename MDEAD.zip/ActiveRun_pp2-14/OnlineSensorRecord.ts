interface OnlineSensorRecord {
	Sensor: OnlineSensorEnum;
	SensorState: SensorStateEnum;
	SensorHealth: RunHealthEnum;
	StreamLoad: number;
}