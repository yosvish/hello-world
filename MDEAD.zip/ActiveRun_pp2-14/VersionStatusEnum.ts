enum VersionStatusEnum {
    Unknown = 0,
    Operational = 1,
    Experimental = 2,
	Previous = 3
}