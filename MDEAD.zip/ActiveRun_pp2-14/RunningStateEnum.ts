enum RunningStateEnum {
    Unknown = 0,
    Play = 1,
    Paused = 2,
    Completed = 3,
	Stopped = 4,
}