enum OnlineSensorEnum {
    Unknown = 0,
    Temperature = 1,
    Acoustic = 2,
    Rpm = 3,
}