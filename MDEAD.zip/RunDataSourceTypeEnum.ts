enum RunDataSourceTypeEnum {
    Uknown = 0,
    Online = 1,
    Recording = 2,
    Merge = 3,
}