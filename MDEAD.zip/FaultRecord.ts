interface FaultRecord {
	Id: number,
	Name: string,
	FaultConfidence: ConfidenceEnum,
	FaultSeverity: SeverityEnum,
	FaultProbability: number,
	EventId: number
}