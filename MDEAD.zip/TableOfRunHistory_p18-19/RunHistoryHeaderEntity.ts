interface RunHistoryHeaderEntity {
    Id: string;
    Type: string;
    RunId: string;
    Description: string;
    Owner: string;
    RunType: RunTypeEnum;
    DataSource: RunDataSourceTypeEnum;
	OnlineSensors: OnlineSensorRecord[];
    Repository: RunRepositoryEnum;
    EngineVersion: VersionRecord;
    RulesVersion: VersionRecord;
    StartTime: Date;
    FinishTime: Date;
	RunDuration: number; //minutes
	SnapshotInterval;  //minutes
    IsCompleted: boolean;
}