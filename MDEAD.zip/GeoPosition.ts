interface GeoPosition {
	Latitude: number;
	Longitude: number;
	Altitude: number;
}
