interface TimePeriod {
	StartTime: Date;
	FinishTime: Date;
}