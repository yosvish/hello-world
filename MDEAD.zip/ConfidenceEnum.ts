enum ConfidenceEnum {
    Unknown = 0,
    NoConfidence = 1,
    LowConfidence = 2,
    MediumConfidence = 3,
    HighConfidence = 4,
}