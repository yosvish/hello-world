enum RunHealthEnum {
    Unknown = 0,
    Ok = 1,
    PartialOk = 2,
    Failure = 3,
}