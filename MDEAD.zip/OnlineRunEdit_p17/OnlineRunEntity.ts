interface OnlineRunEntity {
    Id: string;
    Type: string;
    RunId: string;
    Description: string;
    Owner: string;
    Repository: RunRepositoryEnum;
    OnlineSensors: OnlineSensorRecord[];
    EngineVersion: VersionRecord;
    RulesVersion: VersionRecord;
	SnapshotInterval;  //minutes
}