interface DrillDownFaultEntity {
	RunId: number;
	EventId: number;
	Fault: FaultNameRecord;
	FaultStartTime: Date;
	LastUpdatedTime: Date;
	Anomalies: AnomalyLogRecord[];
	LowConfidenceTime: TimePeriod;
	MediumConfidenceTime: TimePeriod;
	HighConfidenceTime: TimePeriod;
}