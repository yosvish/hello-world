enum SnapshotOrderEnum {
    Unknown = 0,
    Previous = 1,
    Current = 2,
	Next = 3,
}