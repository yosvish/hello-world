interface SnapshotEntity {
    Id: string;
    Type: string;
	RunId: number;
	SnapshotShift: number;
	Status: RunStatusRecord;
	Events: EventRecord[];
	Platforms: PlatformRecord[];
}