interface RunDpComponent {
    Component: RunDpComponentEnum;
    Health: RunHealthEnum;
	Load: number;
}