interface RunStatusRecord {
    RunId: number;
    EventId: number;
    RunHealth: RunHealthEnum;
    RunComponentHealth: RunDpComponent[];
}