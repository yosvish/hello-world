enum SeverityEnum {
    Unknown = 0,
    Minor = 1,
    Major = 2,
}