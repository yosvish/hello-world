interface AnomalyRecord {
	AnomalyName: string;
	AnomalyNumber: number;
}