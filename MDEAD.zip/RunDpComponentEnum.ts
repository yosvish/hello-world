enum RunDpComponentEnum {
    Unknown = 0,
    Input = 1,
    Player = 2,
    DataProcessing = 3,
    AnomalyDetection = 4,
    FaultAnalysis = 5,
}