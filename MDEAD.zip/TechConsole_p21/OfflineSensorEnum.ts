enum OnlineSensorEnum {
    Unknown = 0,
    Recording1 = 1,
    Recording2 = 2,
    Recording3 = 3,
}