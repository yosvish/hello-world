interface OnlineSensorEntity {
	Sensor: OnlineSensorRecord;
}