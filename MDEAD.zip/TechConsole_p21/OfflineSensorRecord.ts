interface OfflineSensorRecord {
	Sensor: OfflineSensorEnum;
	SensorState: SensorStateEnum;
	SensorHealth: RunHealthEnum;
}