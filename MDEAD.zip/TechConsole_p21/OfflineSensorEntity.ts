interface OfflineSensorEntity {
	Sensor: OfflineSensorRecord;
}