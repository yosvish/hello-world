enum EventActivityEnum {
    Unknown = 0,
    New = 1,
    Active = 2,
    NoActive = 3,
    TechnicalOverride = 4
}