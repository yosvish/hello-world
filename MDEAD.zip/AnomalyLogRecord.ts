interface AnomalyLogRecord {
	AnomalyName: string;
	AnomalyNumber: number;
	Times: TimePeriod[];
}