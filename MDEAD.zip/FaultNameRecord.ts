interface FaultNameRecord {
	FaultNumber: number;
	FaultName: string;
}