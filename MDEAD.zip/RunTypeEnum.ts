enum RunTypeEnum {
    Unknown = 0,
    MainOnline = 1,
    ExperimentalOnline = 2,
    Offline = 3,
}