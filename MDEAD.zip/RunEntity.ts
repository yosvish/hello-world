interface RunEntity {
    Id: string;
    Type: string;
    RunId: string;
    Description: string;
    Owner: string;
    RunType: RunTypeEnum;
    RunHealth: RunHealthEnum;
    RunComponentsHealth: RunDpComponent[];
    DataSourceType: RunDataSourceTypeEnum;
    Repository: RunRepositoryEnum;
    EngineVersion: string;
    RulesVersion: string;
    StartTime: Date;
    PlayTime: number;
    PlannedFinishTime: Date;
}